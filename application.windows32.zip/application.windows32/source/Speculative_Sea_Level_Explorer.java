import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 
import codeanticode.glgraphics.*; 
import java.nio.channels.FileChannel; 
import java.nio.Buffer; 
import java.nio.ByteBuffer; 
import java.nio.ShortBuffer; 
import java.nio.ByteOrder; 
import de.fhpotsdam.unfolding.mapdisplay.*; 
import de.fhpotsdam.unfolding.utils.*; 
import de.fhpotsdam.unfolding.marker.*; 
import de.fhpotsdam.unfolding.tiles.*; 
import de.fhpotsdam.unfolding.interactions.*; 
import de.fhpotsdam.unfolding.ui.*; 
import de.fhpotsdam.unfolding.*; 
import de.fhpotsdam.unfolding.core.*; 
import de.fhpotsdam.unfolding.data.*; 
import de.fhpotsdam.unfolding.geo.*; 
import de.fhpotsdam.unfolding.texture.*; 
import de.fhpotsdam.unfolding.events.*; 
import de.fhpotsdam.utils.*; 
import de.fhpotsdam.unfolding.providers.*; 
import controlP5.*; 
import java.awt.event.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Speculative_Sea_Level_Explorer extends PApplet {

// for processing 1.5.1

/*
  Benedikt Gross Copyright (c) 2013 
  http://benedikt-gross.de/log/2013/04/speculative-sea-level-explorer/

  hillshade.pde is based on hillshade.cpp by Matthew Perry
  http://perrygeo.googlecode.com/svn/trunk/demtools/hillshade.cpp

  This sourcecode is free software; you can redistribute it and/or modify it under the terms 
  of the GNU Lesser General Public License as published by the Free Software Foundation; 
  either version 2.1 of the License, or (at your option) any later version.

  This Sourcecode is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public License along with this 
  library; if not, write to the Free Software Foundation, Inc., 51 Franklin St, Fifth Floor, 
  Boston, MA 02110, USA
 */





 























int sealevelMinSetting = -2000;
int sealevelMaxSetting = 2000;

UnfoldingMap map;

ControlP5 cp5;
ControlGroup g1;
RadioButton radio;
Slider seaLevelChangeSlider;

int seaLevelChange = 0;
int seaHigh = color(110, 202, 223 );
int seaBottom = color(74, 148, 160 );
PImage colorMap;
PFont font, fontSmall;

float maxLat, minLat;
float maxLon, minLon;
int srtmResX = 4800;
int srtmResY = 6000;
float[][] srtmRaw = new float[srtmResX][srtmResY];// elevations in meters
int elevations[][];
int maxElevation;
int minElevation;

PGraphics buf;
boolean showOverlay = true;
boolean showSeaLevelAtCursor = false;

BicubicInterpolator bi = new BicubicInterpolator();

boolean doUpdate = true; // FIXME workaround -> buggy controlP5 event reflection
boolean savePng = false;

boolean saveSequence = false;
boolean animateUp = false;
boolean srtmLoaded = false;
int seaLevelChangeStepSize = 30;

String prefix = "";


public void setup() {
  println("helo");
  frame.setTitle("Speculative Sea Level Explorer");

  size(1280, 720, GLConstants.GLGRAPHICS);
  cursor(CROSS);

  buf = createGraphics(width, height, P2D);
  colorMap = loadImage("color_map_bene_B_02.png");

  font = loadFont("Akkurat-Bold-35.vlw");
  fontSmall = loadFont("Akkurat-Bold-8.vlw");

  setupGUI();

  addMouseWheelListener(new MouseWheelListener() { 
    public void mouseWheelMoved(MouseWheelEvent mwe) { 
      doUpdate = true;
    }
  }
  ); 

  // -- setup map --
  //map = new de.fhpotsdam.unfolding.Map(this, "map", 0, 0, width, height, true, false, new Microsoft.AerialProvider());
  map = new UnfoldingMap(this, new Microsoft.HybridProvider());
  map.setTweening(false);
  MapUtils.createDefaultEventDispatcher(this, map);

  // -- init elevation data --
  loadElevationData( new File( dataPath("w020n90.Bathymetry.srtm") ) );

  radio.activate(3);
}


public void draw() {
  if (doUpdate) {
    updateElevationOverlay();
    doUpdate = false;
  }

  background(0);
  map.draw();
  noStroke();

  if (showOverlay) {
    if (mousePressed == false){
      drawOverlay();
    } else if (g1.isOpen() && mouseX < 200) {
      drawOverlay();
    }
  }

  if (!srtmLoaded){
    textFont(font);
    text("< -- Please load a SRTM file! :)", 170, 620); 
  }

  if (showSeaLevelAtCursor) {
    String seaLevelAtCursor = elevations[mouseX][mouseY]+ "";
    fill(0);
    textFont(fontSmall);
    rect(mouseX+10, mouseY+13, textWidth(seaLevelAtCursor), -12);
    fill(255);
    text(seaLevelAtCursor, mouseX+10, mouseY+10);
  }

  if (saveSequence) {
    updateElevationOverlay();
    if (animateUp) {
      saveFrame(prefix+"_up_####.png");
      seaLevelChange = seaLevelChange + seaLevelChangeStepSize; 
    } else {
      saveFrame(prefix+"_down_####.png");
      seaLevelChange = seaLevelChange - seaLevelChangeStepSize;
    }
  }

  if (savePng) {
    saveFrame(timestamp()+".png");
    savePng = false;
  }

  cp5.draw();
}


public void drawOverlay() {
  image(buf, 0, 0);
  // sealevel counter
  String txt;
  if (seaLevelChange > 0) txt = prefix+"+"+seaLevelChange;
  else if (seaLevelChange == 0) txt = prefix+"  "+seaLevelChange;
  else txt = prefix+" "+seaLevelChange;
  txt += " m ";
  textAlign(LEFT);
  textFont(font);
  fill(0);
  float txtWidth = textWidth(txt);
  rect(width-txtWidth, 37, txtWidth, -38);
  fill(255);
  text(txt, width-txtWidth, 30);
}


public void saveSnapshot() {
  savePng = true;
}


public void openSRTMFile() {
  String loadPath = selectInput("Please select a SRTM file");
  if (loadPath == null) {
    println("No file was selected...");
  } 
  else {
    loadElevationData( new File(loadPath) );
    doUpdate = true;
  }
}


public void mouseReleased() {
  if (g1.isOpen()){
    if (mouseX > 200) doUpdate = true;
  } else {
    doUpdate = true;
  }
}


public void radioButton(int index) {
  if (index != -1){
    if (index == 0) {
      seaLevelChange = +1000;
    } else if (index == 1) {
      seaLevelChange = +150;
    } else if (index == 2) {
      seaLevelChange = +6;
    } else if (index == 3) {
      seaLevelChange = 0;
    } else if (index == 4) {
      seaLevelChange = -60;
    } else if (index == 5) {
      seaLevelChange = -130;
    }
    seaLevelChangeSlider.setValue(seaLevelChange);
    doUpdate = true;
  }
}


public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isFrom(cp5.getController("seaLevelChange"))) {
    doUpdate = true;
    radio.activate(-1);
  }
}


// -- load elevation data --
public void loadElevationData(File srtmFile) {
  println("loadElevationData() ->" + srtmFile);
  File file = srtmFile;

  // reset globals
  maxLat=0;
  minLat=0;
  maxLon=0;
  minLon=0;
  maxElevation = Integer.MIN_VALUE;
  minElevation = Integer.MAX_VALUE;

  // load srtm bounds
  String[] loadTxt = loadStrings("SRTM_gridraster_info.txt");
  boolean srtmFound = false;
  for (int i=0; i<loadTxt.length; i++) {
    String[] tokens = trim(split(loadTxt[i], ','));
    if (file.getName().equals(tokens[0])) {
      maxLat = PApplet.parseFloat(tokens[4]);
      minLat = PApplet.parseFloat(tokens[3]);
      maxLon = PApplet.parseFloat(tokens[2]);
      minLon = PApplet.parseFloat(tokens[1]);
      srtmFound = true;
    }
  }
  if (!srtmFound) println("### ERROR \u2013> no srtm file found ###");

  // read srtm binary file
  try {
    FileChannel fc = new FileInputStream(file).getChannel();
    ByteBuffer bb = ByteBuffer.allocateDirect((int) fc.size());

    while (bb.remaining () > 0) fc.read(bb);
    fc.close();
    bb.flip();

    // choose the right endianness
    ShortBuffer sb = bb.order(ByteOrder.BIG_ENDIAN).asShortBuffer();

    int counterX = 0;
    int counterY = 0;

    while (sb.hasRemaining ()) {
      int ele = sb.get();
      srtmRaw[counterX][counterY] = ele;
      maxElevation = max(maxElevation, ele);
      minElevation = min(minElevation, ele);
      counterX++;
      if (counterX == srtmResX) {
        counterX = 0;
        counterY++;
      }
    }
    srtmLoaded = true;
  } 
  catch (Exception e) {
    srtmLoaded = false;
    println("### ERROR \u2013> data loading ###");
  }

  println("maxElevation: "+maxElevation);
  println("minElevation: "+minElevation);

  map.zoomToLevel(4);
  map.panTo(new Location( minLat+(maxLat-minLat)/2, minLon+(maxLon-minLon)/2 ));
}


public void updateElevationOverlay() {
  Location topLeft = map.getLocationFromScreenPosition(0, 0);
  int[] topLeftIndex = locToSRTMIndex(topLeft);
  Location botRight = map.getLocationFromScreenPosition(width, height);
  int[] botRightIndex = locToSRTMIndex(botRight);

  float top = topLeft.getLat();
  float bottom = botRight.getLat();
  float left = topLeft.getLon(); 
  float right = botRight.getLon();
  println("top: "+top +"  bottom: "+bottom+"  left: "+left+"  right: "+right);

  int localResX = botRightIndex[0] - topLeftIndex[0]; 
  int localResY = botRightIndex[1] - topLeftIndex[1];
  println("localResX: "+localResX +"  localResY: "+localResY);

  // interpolate big srtm array to smaller one
  elevations = new int[width][height];
  for (int x=0; x<width; x++) {
    for (int y=0; y<height; y++) {
      float indexX = map(x, 0, width-1, topLeftIndex[0], botRightIndex[0]);
      float indexY = map(y, 0, height-1, topLeftIndex[1], botRightIndex[1]);
      indexX = constrain(indexX, 0, srtmResX-1);
      indexY = constrain(indexY, 0, srtmResY-1);
      elevations[x][y] = round( bi.getValue(srtmRaw, indexX, indexY) );
    }
  }

  // hillshades
  int[][] hillshades = hillshade(elevations, (maxLat-minLat), (maxLon-minLon), width, height);

  // draw
  buf.beginDraw();
  buf.background(255, 0);
  buf.noStroke();

  for (int x=0; x<width; x++) {
    for (int y=0; y<height; y++) {
      int ele = elevations[x][y];
      int col = colorMap.get(0, constrain(ele+100-seaLevelChange, 0, colorMap.height-1));
      int hillshadeVal = (int) map(hillshades[x][y], 0, 255, 90, 255);
      int hillshade = color(hillshadeVal);
      if (ele > seaLevelChange) {
        col = blendColor(hillshade, col, MULTIPLY);
      } 
      else {
        if (ele < -300) {
          int tmp;
          float amt = map(ele, -300, -10000, 0, 1);
          amt = constrain(amt, 0, 1);
          tmp = lerpColor(seaHigh, seaBottom, amt);
          col = blendColor(hillshade, tmp, MULTIPLY);
        } 
        else {
          col = blendColor(hillshade, seaHigh, MULTIPLY);
        }
      }   
      buf.fill( col );
      buf.rect(x, y, 1, 1);
    }
  }

  buf.endDraw();
}


public int[] locToSRTMIndex(Location loc) {
  float lat = loc.getLat();
  float lon = loc.getLon();
  int y = round( map(lat, maxLat, minLat, 0, srtmResY) );
  int x = round( map(lon, minLon, maxLon, 0, srtmResX) );
  int[] xy = {
    x, y
  };
  return xy;
}


public String timestamp() {
  Calendar now = Calendar.getInstance();
  return String.format("%1$ty%1$tm%1$td_%1$tH%1$tM%1$tS", now);
}

public void setupGUI() {
  int activeColor = color(157,165,15);

  // -- setup gui --
  cp5 = new ControlP5(this);
  cp5.setColorActive(activeColor);
  cp5.setColorBackground(color(70));
  cp5.setColorForeground(color(128));
  cp5.setColorLabel(color(255));
  cp5.setColorValue(color(255));
  cp5.setAutoDraw(false);

  g1 = cp5.addGroup("g1")
    .setPosition(0,10)
    .setWidth(140)
    .setBackgroundHeight(height)
    .setBackgroundColor(color(0))
    .setLabel("CTRL")
    ;
    
  seaLevelChangeSlider = cp5.addSlider("seaLevelChange")
   .setRange(sealevelMinSetting,sealevelMaxSetting)
   .setValue(0)
   .setPosition(5,10)
   .setTriggerEvent(Slider.RELEASE)
   .setSize(50,345)
   .setGroup(g1)
   .setLabel("Sea-Level Change (Meters)")
   ;

  radio = cp5.addRadioButton("radioButton")
   .setPosition(5,380)
   .setSize(15,15)
   .setItemsPerRow(1)
   .setSpacingColumn(50)
   .addItem("+1000  Waterworld",0)
   .addItem("+150  The Hunger Games",1)
   .addItem("+6  Melting of Ice Sheets",2)
   .addItem("0  Current Sea-Level",3)
   .addItem("-60  Early Holocene",4)
   .addItem("-130  Last Glacial Maximum",5)
   .setGroup(g1)
   ;
   
  cp5.addToggle("showOverlay")
   .setPosition(5,490)
   .setSize(50,20)
   .setValue(true)
   .setMode(ControlP5.SWITCH)
   .setGroup(g1)
   .setLabel("Show Bing Map Only")
   ;
   
  cp5.addToggle("showSeaLevelAtCursor")
   .setPosition(5,530)
   .setSize(50,20)
   .setValue(false)
   .setMode(ControlP5.SWITCH)
   .setGroup(g1)
   .setLabel("Show Sea-Level at Cursor")
   ;
   
  cp5.addBang("openSRTMFile")
   .setPosition(5, 570)
   .setSize(50, 50)
   .setTriggerEvent(Bang.RELEASE)
   .setGroup(g1)
   .setLabel("Load SRTM File")
   ;

  cp5.addBang("saveSnapshot")
   .setPosition(5, 640)
   .setSize(50, 50)
   .setTriggerEvent(Bang.RELEASE)
   .setGroup(g1)
   .setLabel("Save Image")
   ;
}
//http://stackoverflow.com/questions/9668821/array-interpolation

public static class CubicInterpolator {
    public static double getValue(double[] p, double x) {
        int xi = (int) x;
        x -= xi;
        double p0 = p[Math.max(0, xi - 1)];
        double p1 = p[xi];
        double p2 = p[Math.min(p.length - 1,xi + 1)];
        double p3 = p[Math.min(p.length - 1, xi + 2)];
        return p1 + 0.5f * x * (p2 - p0 + x * (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3 + x * (3.0f * (p1 - p2) + p3 - p0)));
    }
    public static float getValue(float[] p, float x) {
        int xi = (int) x;
        x -= xi;
        float p0 = p[Math.max(0, xi - 1)];
        float p1 = p[xi];
        float p2 = p[Math.min(p.length - 1,xi + 1)];
        float p3 = p[Math.min(p.length - 1, xi + 2)];
        return p1 + 0.5f * x * (p2 - p0 + x * (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3 + x * (3.0f * (p1 - p2) + p3 - p0)));
    }
    public static int getValue(int[] p, int x) {
        int xi = x;
        x -= xi;
        int p0 = p[Math.max(0, xi - 1)];
        int p1 = p[xi];
        int p2 = p[Math.min(p.length - 1,xi + 1)];
        int p3 = p[Math.min(p.length - 1, xi + 2)];
        return Math.round( p1 + 0.5f * x * (p2 - p0 + x * (2.0f * p0 - 5.0f * p1 + 4.0f * p2 - p3 + x * (3.0f * (p1 - p2) + p3 - p0))) );
    }
}

public static class BicubicInterpolator extends CubicInterpolator {
    public static double getValue(double[][] p, double x, double y) {
        double[] arr = new double[4];
        int xi = (int) x;
        x -= xi;
        arr[0] = getValue(p[Math.max(0, xi - 1)], y);
        arr[1] = getValue(p[xi], y);
        arr[2] = getValue(p[Math.min(p.length - 1,xi + 1)], y);
        arr[3] = getValue(p[Math.min(p.length - 1, xi + 2)], y);
        return getValue(arr, x+ 1);
    }
    public static float getValue(float[][] p, float x, float y) {
        float[] arr = new float[4];
        int xi = (int) x;
        x -= xi;        
        arr[0] = getValue(p[Math.max(0, xi - 1)], y);
        arr[1] = getValue(p[xi], y);
        arr[2] = getValue(p[Math.min(p.length - 1,xi + 1)], y);
        arr[3] = getValue(p[Math.min(p.length - 1, xi + 2)], y);
        return getValue(arr, x+ 1);
    }
    public static int getValue(int[][] p, int x, int y) {
        int[] arr = new int[4];
        int xi = x;
        x -= xi;
        arr[0] = getValue(p[Math.max(0, xi - 1)], y);
        arr[1] = getValue(p[xi], y);
        arr[2] = getValue(p[Math.min(p.length - 1,xi + 1)], y);
        arr[3] = getValue(p[Math.min(p.length - 1, xi + 2)], y);
        return getValue(arr, x+ 1);
    }
}
// based on hillshade.cpp by Matthew Perry
// http://perrygeo.googlecode.com/svn/trunk/demtools/hillshade.cpp

public int[][] hillshade(int[][] elevations, float ewres, float nsres, int nXSize, int nYSize) {

  int[][] shadeBuf = new int[nXSize][nYSize];

  int nullValue = 0; // could be any number

  float z = 1.0f;
  float scale = 1.0f;
  float az = 315-270;
  float alt = 65.0f;
  float radiansToDegrees = 180.0f / 3.14159f;
  float degreesToRadians = 3.14159f / 180.0f;

  // tmp vars all used in for loop
  float[] win = new float[9];
  boolean containsNull;
  float cang;
  float x, y;
  float slope, aspect;

  for (int i = 0; i < nYSize; i++) {
    for (int j = 0; j < nXSize; j++) {
      containsNull = false;

      // Exclude the edges
      if (i == 0 || j == 0 || i == nYSize-1 || j == nXSize-1 )
      {
        // We are at the edge so write nullValue and move on
        shadeBuf[j][i] = nullValue;
        containsNull = true;
        continue;
      }

      // Read in 3x3 window
      /* ------------------------------------------
       * Move a 3x3 window over each cell 
       * (where the cell in question is #4)
       *
       *                 0 1 2
       *                 3 4 5
       *                 6 7 8
       */
      win[0] = elevations[j-1][i-1];
      win[1] = elevations[j  ][i-1];
      win[2] = elevations[j+1][i-1];

      win[3] = elevations[j-1][i  ];
      win[4] = elevations[j  ][i  ];
      win[5] = elevations[j+1][i  ];

      win[6] = elevations[j-1][i+1];
      win[7] = elevations[j  ][i+1];
      win[8] = elevations[j+1][i+1];

      if (containsNull) {
        // We have nulls so write nullValue and move on
        shadeBuf[j][i] = nullValue;
        continue;
      } 
      else {        
        // We have a valid 3x3 window.

        /* ---------------------------------------
         * Compute Hillshade
         */

        // First Slope ...
        x = ((z*win[0] + z*win[3] + z*win[3] + z*win[6]) -
          (z*win[2] + z*win[5] + z*win[5] + z*win[8])) /
          (8.0f * ewres * scale);

        y = ((z*win[6] + z*win[7] + z*win[7] + z*win[8]) -
          (z*win[0] + z*win[1] + z*win[1] + z*win[2])) /
          (8.0f * nsres * scale);

        slope = 90.0f - atan(sqrt(x*x + y*y))*radiansToDegrees;

        // ... then aspect...
        aspect = atan2(x, y);

        // ... then the shade value
        cang = sin(alt*degreesToRadians) * sin(slope*degreesToRadians) +
          cos(alt*degreesToRadians) * cos(slope*degreesToRadians) *
          cos((az-90.0f)*degreesToRadians - aspect);

        if (cang <= 0.0f) cang = nullValue;
        else cang = 255.0f * cang;

        shadeBuf[j][i] = (int)cang;
      }
    }
  }
  
  return shadeBuf;
}

  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#F0F0F0", "Speculative_Sea_Level_Explorer" });
  }
}
